// src/routes/scores.js

const express = require("express");
const router = express.Router();

const { pool } = require("../db");
const { authenticateJWT } = require("../middleware/auth");
const { requireRole } = require("../middleware/role");

/**
 * =========================
 * SCORES (NON-SPATIAL RESOURCE)
 * Table: scores
 *
 * Columns (senin DB'ye göre):
 *  - id (int)
 *  - user_id (uuid)
 *  - guessed_lat, guessed_lng, true_lat, true_lng (double)
 *  - score (int)
 *  - created_at (timestamptz)
 *  - guessed_geom, true_geom (geometry)
 *
 * Rules:
 *  - GET allowed: admin / player / viewer
 *      - admin: all scores (default)
 *      - player/viewer: only their own scores
 *      - admin can do ?mine=true to see only own
 *  - POST/PUT/DELETE allowed: admin / player (viewer forbidden)
 *  - PUT/DELETE: admin OR owner
 * =========================
 */

// GET /scores -> admin all, player/viewer only own
// Optional: ?mine=true (admin için kendi skorları)
router.get(
  "/",
  authenticateJWT,
  requireRole(["admin", "player", "viewer"]),
  async (req, res) => {
    try {
      const mine = String(req.query.mine || "").toLowerCase() === "true";
      const isAdmin = req.user.role === "admin";

      let sql = `
        SELECT
          id,
          user_id,
          guessed_lat,
          guessed_lng,
          true_lat,
          true_lng,
          score,
          created_at,
          ST_AsGeoJSON(guessed_geom)::json AS guessed_geom,
          ST_AsGeoJSON(true_geom)::json AS true_geom
        FROM scores
      `;

      const where = [];
      const params = [];
      let idx = 1;

      // admin değilse: sadece kendi skorları
      if (!isAdmin) {
        where.push(`user_id = $${idx++}`);
        params.push(req.user.id);
      } else {
        // admin ise mine=true gelirse kendi skorları
        if (mine) {
          where.push(`user_id = $${idx++}`);
          params.push(req.user.id);
        }
      }

      if (where.length > 0) sql += ` WHERE ${where.join(" AND ")} `;
      sql += ` ORDER BY created_at DESC LIMIT 200;`;

      const q = await pool.query(sql, params);
      res.json({ count: q.rows.length, scores: q.rows });
    } catch (err) {
      console.error("GET /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

// GET /scores/:id -> admin OR owner (player/viewer)
router.get(
  "/:id",
  authenticateJWT,
  requireRole(["admin", "player", "viewer"]),
  async (req, res) => {
    try {
      const { id } = req.params;

      const q = await pool.query(
        `
        SELECT
          id,
          user_id,
          guessed_lat,
          guessed_lng,
          true_lat,
          true_lng,
          score,
          created_at,
          ST_AsGeoJSON(guessed_geom)::json AS guessed_geom,
          ST_AsGeoJSON(true_geom)::json AS true_geom
        FROM scores
        WHERE id = $1
        `,
        [id]
      );

      if (q.rows.length === 0) {
        return res.status(404).json({ message: "score not found" });
      }

      const row = q.rows[0];
      const isAdmin = req.user.role === "admin";
      const isOwner = String(row.user_id) === String(req.user.id);

      if (!isAdmin && !isOwner) {
        return res.status(403).json({ message: "Forbidden: not owner" });
      }

      res.json(row);
    } catch (err) {
      console.error("GET /scores/:id error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

// POST /scores -> admin/player (viewer forbidden)
// body: { guessed_lat, guessed_lng, true_lat, true_lng, score }
router.post(
  "/",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { guessed_lat, guessed_lng, true_lat, true_lng, score } =
        req.body || {};

      const required = [guessed_lat, guessed_lng, true_lat, true_lng, score];
      if (required.some((v) => v === undefined || v === null)) {
        return res.status(400).json({
          message:
            "guessed_lat, guessed_lng, true_lat, true_lng, score are required",
        });
      }

      const q = await pool.query(
        `
        INSERT INTO scores
          (user_id, guessed_lat, guessed_lng, true_lat, true_lng, score, guessed_geom, true_geom)
        VALUES
          (
            $1, $2, $3, $4, $5, $6,
            ST_SetSRID(ST_MakePoint($3, $2), 4326),
            ST_SetSRID(ST_MakePoint($5, $4), 4326)
          )
        RETURNING
          id,
          user_id,
          guessed_lat,
          guessed_lng,
          true_lat,
          true_lng,
          score,
          created_at,
          ST_AsGeoJSON(guessed_geom)::json AS guessed_geom,
          ST_AsGeoJSON(true_geom)::json AS true_geom
        `,
        [req.user.id, guessed_lat, guessed_lng, true_lat, true_lng, score]
      );

      res.status(201).json(q.rows[0]);
    } catch (err) {
      console.error("POST /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

// PUT /scores/:id -> admin OR owner (player)
// body: { guessed_lat?, guessed_lng?, true_lat?, true_lng?, score? }
router.put(
  "/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { guessed_lat, guessed_lng, true_lat, true_lng, score } =
        req.body || {};

      const existing = await pool.query(
        "SELECT id, user_id FROM scores WHERE id=$1",
        [id]
      );
      if (existing.rows.length === 0) {
        return res.status(404).json({ message: "score not found" });
      }

      const ownerId = existing.rows[0].user_id;
      const isAdmin = req.user.role === "admin";
      const isOwner = String(ownerId) === String(req.user.id);

      if (!isAdmin && !isOwner) {
        return res.status(403).json({ message: "Forbidden: not owner" });
      }

      const sets = [];
      const params = [];
      let idx = 1;

      // scalar updates
      if (guessed_lat !== undefined) {
        sets.push(`guessed_lat=$${idx++}`);
        params.push(guessed_lat);
      }
      if (guessed_lng !== undefined) {
        sets.push(`guessed_lng=$${idx++}`);
        params.push(guessed_lng);
      }
      if (true_lat !== undefined) {
        sets.push(`true_lat=$${idx++}`);
        params.push(true_lat);
      }
      if (true_lng !== undefined) {
        sets.push(`true_lng=$${idx++}`);
        params.push(true_lng);
      }
      if (score !== undefined) {
        sets.push(`score=$${idx++}`);
        params.push(score);
      }

      // geom updates: pair requirement
      const hasGLat = guessed_lat !== undefined;
      const hasGLng = guessed_lng !== undefined;
      if (hasGLat || hasGLng) {
        if (!(hasGLat && hasGLng)) {
          return res.status(400).json({
            message:
              "Both guessed_lat and guessed_lng required to update guessed_geom",
          });
        }
        // ST_MakePoint(lng, lat)
        sets.push(
          `guessed_geom=ST_SetSRID(ST_MakePoint($${idx++}, $${idx++}), 4326)`
        );
        params.push(guessed_lng, guessed_lat);
      }

      const hasTLat = true_lat !== undefined;
      const hasTLng = true_lng !== undefined;
      if (hasTLat || hasTLng) {
        if (!(hasTLat && hasTLng)) {
          return res.status(400).json({
            message: "Both true_lat and true_lng required to update true_geom",
          });
        }
        sets.push(
          `true_geom=ST_SetSRID(ST_MakePoint($${idx++}, $${idx++}), 4326)`
        );
        params.push(true_lng, true_lat);
      }

      if (sets.length === 0) {
        return res.status(400).json({ message: "No fields to update" });
      }

      params.push(id);

      const q = await pool.query(
        `
        UPDATE scores
        SET ${sets.join(", ")}
        WHERE id = $${idx}
        RETURNING
          id,
          user_id,
          guessed_lat,
          guessed_lng,
          true_lat,
          true_lng,
          score,
          created_at,
          ST_AsGeoJSON(guessed_geom)::json AS guessed_geom,
          ST_AsGeoJSON(true_geom)::json AS true_geom
        `,
        params
      );

      res.json(q.rows[0]);
    } catch (err) {
      console.error("PUT /scores/:id error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

// DELETE /scores/:id -> admin OR owner (player)
router.delete(
  "/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;

      const existing = await pool.query(
        "SELECT id, user_id FROM scores WHERE id=$1",
        [id]
      );
      if (existing.rows.length === 0) {
        return res.status(404).json({ message: "score not found" });
      }

      const ownerId = existing.rows[0].user_id;
      const isAdmin = req.user.role === "admin";
      const isOwner = String(ownerId) === String(req.user.id);

      if (!isAdmin && !isOwner) {
        return res.status(403).json({ message: "Forbidden: not owner" });
      }

      await pool.query("DELETE FROM scores WHERE id=$1", [id]);
      res.json({ ok: true, deleted_id: id });
    } catch (err) {
      console.error("DELETE /scores/:id error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

module.exports = router;
