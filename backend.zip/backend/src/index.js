const express = require("express");
const cors = require("cors");
require("dotenv").config();

const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { pool } = require("./db");
const { authenticateJWT } = require("./middleware/auth");
const { requireRole } = require("./middleware/role");

const app = express();
app.use(cors());
app.use(express.json());

/* =========================
   HEALTH CHECK
========================= */
app.get("/health", (req, res) => {
  res.json({ ok: true, message: "Backend is running" });
});

/* =========================
   AUTH – DEMO LOGIN
========================= */
app.post("/demo-login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ message: "email & password required" });
    }

    const q = await pool.query(
      "SELECT id, email, password_hash, role FROM users WHERE email=$1",
      [email]
    );
    if (q.rows.length === 0) {
      return res.status(401).json({ message: "invalid credentials" });
    }

    const user = q.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ message: "invalid credentials" });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      token,
      user: { id: user.id, email: user.email, role: user.role },
    });
  } catch (err) {
    console.error("POST /demo-login error:", err);
    res.status(500).json({ message: "server error" });
  }
});

/* =========================
   USER INFO
========================= */
app.get(
  "/me",
  authenticateJWT,
  requireRole(["admin", "player", "viewer"]),
  (req, res) => {
    res.json({ me: req.user });
  }
);

/* ============================================================
   PART 4 + PART 8 — SPATIAL RESOURCE: POINTS
============================================================ */

/**
 * GET /points
 * Filters:
 *   ?mine=true
 *   ?category=xxx
 *   ?bbox=minLng,minLat,maxLng,maxLat
 */
app.get(
  "/points",
  authenticateJWT,
  requireRole(["admin", "player", "viewer"]),
  async (req, res) => {
    try {
      const mine = String(req.query.mine || "") === "true";
      const category = req.query.category || null;
      const bbox = req.query.bbox || null;

      let sql = `
        SELECT
          id, owner_id, name, category, description,
          created_at, updated_at,
          ST_AsGeoJSON(geom)::json AS geom
        FROM points
      `;

      const where = [];
      const params = [];
      let idx = 1;

      if (mine && req.user.role !== "admin") {
        where.push(`owner_id = $${idx++}`);
        params.push(req.user.id);
      }

      if (category) {
        where.push(`category = $${idx++}`);
        params.push(category);
      }

      if (bbox) {
        const [minLng, minLat, maxLng, maxLat] = bbox.split(",").map(Number);
        where.push(
          `geom && ST_MakeEnvelope($${idx++}, $${idx++}, $${idx++}, $${idx++}, 4326)`
        );
        params.push(minLng, minLat, maxLng, maxLat);
      }

      if (where.length) sql += ` WHERE ${where.join(" AND ")}`;
      sql += " ORDER BY created_at DESC LIMIT 200";

      const q = await pool.query(sql, params);
      res.json({ count: q.rows.length, points: q.rows });
    } catch (err) {
      console.error("GET /points error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* POST /points */
app.post(
  "/points",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { name, category, description, lng, lat } = req.body || {};
      if (!name || lng === undefined || lat === undefined) {
        return res.status(400).json({ message: "name, lng, lat required" });
      }

      const q = await pool.query(
        `
        INSERT INTO points (owner_id, name, category, description, geom)
        VALUES ($1,$2,$3,$4,ST_SetSRID(ST_MakePoint($5,$6),4326))
        RETURNING id, owner_id, name, category, description,
          created_at, updated_at,
          ST_AsGeoJSON(geom)::json AS geom
        `,
        [req.user.id, name, category, description, lng, lat]
      );

      res.status(201).json(q.rows[0]);
    } catch (err) {
      console.error("POST /points error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* PUT /points/:id */
app.put(
  "/points/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      const existing = await pool.query(
        "SELECT owner_id FROM points WHERE id=$1",
        [id]
      );
      if (!existing.rows.length)
        return res.status(404).json({ message: "point not found" });

      const isOwner = String(existing.rows[0].owner_id) === String(req.user.id);
      if (req.user.role !== "admin" && !isOwner)
        return res.status(403).json({ message: "Forbidden" });

      const { name, category, description, lng, lat } = req.body || {};
      const sets = [];
      const params = [];
      let idx = 1;

      if (name !== undefined) sets.push(`name=$${idx++}`), params.push(name);
      if (category !== undefined)
        sets.push(`category=$${idx++}`), params.push(category);
      if (description !== undefined)
        sets.push(`description=$${idx++}`), params.push(description);

      if (lng !== undefined && lat !== undefined) {
        sets.push(
          `geom=ST_SetSRID(ST_MakePoint($${idx++},$${idx++}),4326)`
        );
        params.push(lng, lat);
      }

      params.push(id);

      const q = await pool.query(
        `
        UPDATE points SET ${sets.join(", ")}, updated_at=NOW()
        WHERE id=$${idx}
        RETURNING id, owner_id, name, category, description,
          created_at, updated_at,
          ST_AsGeoJSON(geom)::json AS geom
        `,
        params
      );

      res.json(q.rows[0]);
    } catch (err) {
      console.error("PUT /points error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* DELETE /points/:id */
app.delete(
  "/points/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      await pool.query("DELETE FROM points WHERE id=$1", [id]);
      res.json({ ok: true, deleted_id: id });
    } catch (err) {
      console.error("DELETE /points error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* ============================================================
   PART 8 — NON-SPATIAL RESOURCE: SCORES
============================================================ */

/* GET /scores */
app.get(
  "/scores",
  authenticateJWT,
  requireRole(["admin", "player", "viewer"]),
  async (req, res) => {
    try {
      const isAdmin = req.user.role === "admin";
      const q = await pool.query(
        `
        SELECT
          id, user_id, guessed_lat, guessed_lng,
          true_lat, true_lng, score, created_at,
          ST_AsGeoJSON(guessed_geom)::json AS guessed_geom,
          ST_AsGeoJSON(true_geom)::json AS true_geom
        FROM scores
        ${isAdmin ? "" : "WHERE user_id = $1"}
        ORDER BY created_at DESC
        `,
        isAdmin ? [] : [req.user.id]
      );

      res.json({ count: q.rows.length, scores: q.rows });
    } catch (err) {
      console.error("GET /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* POST /scores */
app.post(
  "/scores",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { guessed_lat, guessed_lng, true_lat, true_lng, score } = req.body;

      const q = await pool.query(
        `
        INSERT INTO scores
        (user_id, guessed_lat, guessed_lng, true_lat, true_lng, score,
         guessed_geom, true_geom)
        VALUES
        ($1,$2,$3,$4,$5,$6,
         ST_SetSRID(ST_MakePoint($3,$2),4326),
         ST_SetSRID(ST_MakePoint($5,$4),4326))
        RETURNING *
        `,
        [req.user.id, guessed_lat, guessed_lng, true_lat, true_lng, score]
      );

      res.status(201).json(q.rows[0]);
    } catch (err) {
      console.error("POST /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* PUT /scores/:id */
app.put(
  "/scores/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      const q = await pool.query(
        "UPDATE scores SET score=$1 WHERE id=$2 RETURNING *",
        [req.body.score, id]
      );
      res.json(q.rows[0]);
    } catch (err) {
      console.error("PUT /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* DELETE /scores/:id */
app.delete(
  "/scores/:id",
  authenticateJWT,
  requireRole(["admin", "player"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      await pool.query("DELETE FROM scores WHERE id=$1", [id]);
      res.json({ ok: true, deleted_id: id });
    } catch (err) {
      console.error("DELETE /scores error:", err);
      res.status(500).json({ message: "server error" });
    }
  }
);

/* ========================= */
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});
